/* Framework for the two well model */
#include "model.h"


