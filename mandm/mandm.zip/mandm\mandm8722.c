
#pragma	config OSC = HSPLL
#pragma config WDT = ON, WDTPS = 1024
#pragma config BOREN = OFF
#pragma config STVREN = ON
#pragma config LVP=OFF
#define	__MANDM_C			//	This is the main program

/*
 *
 * standard program units:
 * Voltage  in (unsigned long/unsigned int) millivolts,
 * Current in (long) hundredths of amps
 * Watts Power in (unsigned long)
 * 
 *
 * R: structure, real values from measurements
 * C: structure, calculated values from measurements or programs
 * B: structure
 * V: structure, Volatile varables modified in the ISR in a possible non-atomic fashion
 *
 * USART2 		is the host comm port 38400
 * Timer0		1 second clock
 * TImer1		Not used
 * Timer2		Not used
 * Timer3		work thread , background I/O clock ~20HZ
 * TImer4		PWM Period clock

 * 0..8 analog channels are active
 * PORTA		analog inputs
 * adc0	systemvoltage	PIC Controller supply voltage
 * adc1	motorvoltage	24v PS monitor from relay
 * adc2	current_x
 * adc3	current_y
 * adc4	current_z
 * PORTB		HID Qencoder and switch inputs
 * PORTC		HID leds
 * PORTD		configuration switch input
 * PORTE		motor control relays
 * PORTF		analog inputs
 * adc5	rawp1 X pot RF0
 * adc6 rawp2 Y pot RF1
 * adc7 rawp3 Z pot RF2
 * adc8 Ground REF	zero adc charge cap RF3
 * adc_cal[11-14]	current sensors zero offset stored in eeprom 11=x, 12=y, 13=z, 14=future
 * cal table with checksum as last data item in adc_cal[]
 * PORTH0		run flasher led onboard, 4x20 LCD status panel
 * PORTJ		alarm and diag leds
 * PORTG		Alarm and Voice outputs
 *
 *
 * frederick.brooks@microchip.com Copyright 2012
 * Microchip Gresham, Oregon
 */


/*
 *
 * This application is designed for use with the
 * ET-BASE PIC8722 board, 4*20 LCD display
 *
 * RS-232 host commands 38400baud 8n1

 * K		lockup controller causing WDT timer to reboot
 * Z		reset command parser
 * ?		Send help menu to rs-232 terminal
 * $		fuse blown error. (NOT DONE YET)
 * ^		reset current sensor zero calibration
 * !		hold program in present date
 * #		System Status
 *
 */


//	***
//	0.5	    mandm software.
//	1.5	    Find source of LCD glitching, might be ISR related.
//	1.8	    First production release
//	1.9	    Change relay drive from low on to HIGH on for uln2803 buffers. OMRON relays also rewired.
//	2.0	    On V2 hardware with DPDT relays add shorting motor function for brakes and EMI reduction
//	2.1	    Motor QEI isr code and inputs. Use B3 input for A input isr trigger and QEI1_B for B input, use cable codes 8+
//		    buzzer and voice box functions to G0 and G3

//	***
//  dipswitch settings PORTD
//  1       Clear controller data
//  2       on=RS-232 logging DEBUG mode,// log debug text to comm2 port at 38400
//  3	    Cycle LCD display to debug screens.
//  4
//  5
//  6       on=FAIL-SAFE MODE, just turn on all motors.
//  7
//  8
//	***

#include <p18cxxx.h>
#include <delays.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "mandm_defs.h"
#include "xlcd.h"
#include "config.h"
#include "mandm.h"
#include "crit.h"
#include "mandm_msg.h"
#include "hwconf.h"
#include "power.h"
#include "model.h"
#include "mandm_vector.h"
#include "mandm_shared.h"
#include "daq.h"

void clr_lcd(void);
char *ahfp(long, char *);
char *voltfp(unsigned long, char *);
char *voltfps(unsigned long, char *);
char *voltfpi(long, char *);
void MputsXLCD(char *);

void fail_safe(void);
char *hms(unsigned long);
char *hm(unsigned long);
float lp_filter(float, int, int);
void putc2(unsigned char c);
void hold_process(void); // hold monitor progrsm
void system_data(void); // send system variables to rs-232 terminal
void system_help(void); // send system help menu to rs-232 terminal
void exerciser(void); // test calibrated assy
void e220_qei_exer(unsigned char);
unsigned char check_alarm(unsigned char, const rom char*);
long ABSL(long);
int ABSI(int);
void LCD_VC_puts(unsigned char, unsigned char, unsigned char);
void wdttime(unsigned long);
uint8_t checktime(unsigned long, uint8_t);
uint8_t checktime_select(unsigned long, uint8_t);
uint8_t checktime_motor(unsigned long, uint8_t);
uint8_t checktime_cal(unsigned long, uint8_t);
uint8_t checktime_eep(unsigned long, uint8_t);
uint8_t checktime_track(unsigned long, uint8_t);
void wdtdelay(unsigned long);
void update_hist(void);
void term_time(void);
void viision_m_display(void);
void help_m_display(void);
void viision_ms_display(void);
void varian_v_display(void);
void e220_m_display(void);
void e220_qei_display(void);
void gsd_m_display(void);
void default_display(void);
void Set_Cursor(void);
void run_demos(unsigned char);
void run_cal(void);
void display_cal(void);
void init_motordata(uint8_t);
void track_motor(void);
void init_lcd(void);
uint8_t check_cable(uint8_t *);
void fail_all_motors(uint8_t);
void nav_menu(void);
unsigned char spinners(unsigned char, unsigned char);

#pragma udata gpr13
far char bootstr2[MESG_W + 1];
#pragma udata gpr1
char p1[C_TEMP16], p2[C_TEMP16];
char termstr[32];
unsigned char csd[SD_18], cid[SD_18], HCRIT[CRIT_8], LCRIT[CRIT_8];
far char f1[C_TEMP7], f2[C_TEMP7], f3[C_TEMP7], f4[C_TEMP7];
char p3[C_TEMP16];
volatile struct almbuffertype alarm_buffer[MAXALM];
float smooth[LPCHANC];
#pragma udata gpr2
struct lcdb ds[VS_SLOTS]; // , ms[VS_SLOTS]; //  LCD/MENU display strings, name
#pragma udata gpr3
far char hms_string[16];
int a10_x, a10_y, a10_z, worktick;
volatile unsigned char TIMERFLAG = FALSE, PRIPOWEROK = TRUE, FORCEOUT = FALSE, WORKERFLAG = FALSE, critc_level = 0, KEYNUM = 0,
        FAILSAFE = FALSE, SYSTEM_STABLE = FALSE, HOLD_PROC = FALSE, C2RAW, glitch_count,
        DISPLAY_MODE = FALSE, D_UPDATE = TRUE, GLITCH_CHECK = TRUE, COOLING = FALSE,
        UPDATE_EEP = FALSE, RESET_ZEROS = FALSE, SYS_DATA = FALSE, MOD_DATA = FALSE, SYS_HELP = FALSE, SET_ADC = FALSE,
        WDT_TO = FALSE, EEP_ER = FALSE, TWEAK = FALSE, cdelay, TEST_SPINNERS = FALSE,SLOW_STATUS;
#pragma udata gpr4
volatile struct almtype alarm_codes = {FALSE, 0};
volatile struct modetype mode = {FALSE, TRUE, TRUE, HELP_M, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE, FALSE};
volatile unsigned char almctr, RS232_DEBUG = FALSE;
volatile unsigned long critc_count = 0;
#pragma udata gpr5
volatile struct buttontype button;

char sign = ' ';
float lp_speed = 0.0, lp_x = 0.0;
struct R_data R;
struct C_data C;
struct V_data V;
const rom char *build_date = __DATE__, *build_time = __TIME__;
#pragma udata gpr6

volatile unsigned char dsi = 0, msi = 0, help_pos = 0; //      LCD display string index to console 0
float t1 = 0.0, t2 = 0.0, t3 = 0.0, t4 = 0.0, t5 = 0.0, t6 = 0.0, t7 = 0.0, t_time = 0.0;
float voltfrak = 0.0;
float ahfrak = 0.0;
#pragma udata gpr7
unsigned long Vin = 0, chrg_v = 0, vbatol_t = 0, solar_t = 0, rawp[MAX_POT];
volatile unsigned char IDLEFLAG = FALSE, knob_to_pot = XAXIS;
long iw = 0, ip = 0;
#pragma udata gpr8
volatile struct motortype motordata[MAX_MOTOR], *motor_ptr;
#pragma udata gpr9
volatile struct knobtype knob1, knob2;

/* ADC voltage/current default calibration values , adjusted with D command */
// adc_cal[11-14]				current sensors zero offset stored in eeprom 11=x, 12=y, 13=z, 14=future
unsigned char adc_cal[] = {127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 0};
unsigned char CRITC = 0, LCD_OK = FALSE, Cursor[MAX_POT], cable_type = 0x07;

volatile enum answer_t {
    WAIT_M, YES_M, NO_M
} YNKEY;

volatile struct QuadEncoderType OldEncoder;

#pragma idata gpr10
unsigned char lcd18 = 200;
volatile struct qeitype qei1;
volatile long slow_timer=0;

/* ISR vectors */
#pragma code tick_interrupt = HIGH_VECTOR

void tick_int(void) {
    _asm goto tick_handler _endasm // high
}
#pragma code

#pragma code work_interrupt = LOW_VECTOR

void work_int(void) {
    _asm goto work_handler _endasm // low
}
#pragma code

/* Misc ACSII spinner character generator, stores position for each shape */
unsigned char spinners(unsigned char shape, unsigned char reset) {
    static unsigned char s[MAX_SHAPES], last_shape = 0;
    unsigned char c;

    if (shape > (MAX_SHAPES - 1)) shape = 0;
    if (reset) s[shape] = 0;
    last_shape = shape;
    c = spin[shape][s[shape]];
    if (++s[shape] >= strlenpgm(spin[shape])) s[shape] = 0;
    return c;
}

void LCD_VC_puts(unsigned char console, unsigned char line, unsigned char COPY) // VCx,DSx, [TRUE..FALSE} copy data from bootstr2 string
{ // into the LCD display buffer
    static unsigned char ib = 0;

    if (!LCD_OK) return;
    //    lcdhits++;
    if (COPY) {
        ib = console + line; // set to string index to store data in LCD message array ds[x].b
        strncpypgm2ram(ds[ib].b, "                        ", LCD_W); // write 20 space chars
        strncpy(ds[ib].b, bootstr2, LCD_W); // move data from static buffer in lcd message array
        ds[ib].b[LCD_W] = NULL0; // make sure we have a string terminator
    }
    switch (line) {
        case DS0:
            SetDDRamAddr(LL1); // move to  line
            break;
        case DS1:
            SetDDRamAddr(LL2); // move to  line
            break;
        case DS2:
            SetDDRamAddr(LL3); // move to  line
            break;
        case DS3:
            SetDDRamAddr(LL4); // move to  line
            break;
        default:
            SetDDRamAddr(LL1); // move to  line 1 of out of range
            break;
    }
    ib = dsi + line; // set to string index to display on LCD, dsi is the current VC being displayed
    if (!D_UPDATE) return;
    while (BusyXLCD());
    putsXLCD(ds[ib].b);
    while (BusyXLCD());
    LATH &= 0b00000001;
}

void update_hist(void) // compute the runtime data from current data
{

    // check FLAGS from the tick ISR and run subroutine if needed
    if (RESET_ZEROS) { // zero the current sensors
        zero_amploc();
        RESET_ZEROS = FALSE;
    }
    if (SET_ADC) { // Set gains for ADC channel calibration
        SET_ADC = FALSE;
    }
    if (TWEAK) { // Adjust runtime data
        exerciser();
        TWEAK = FALSE;
    }
    if (HOLD_PROC) { // Hold processing, mainly used during a battery EQ cycle.
        hold_process();
        HOLD_PROC = FALSE;
    }
    if (SYS_HELP) { // Command Help message
        system_help();
        SYS_HELP = FALSE;
    }
    if (SYS_DATA) { // display System data on rs-232 port
        system_data();
        SYS_DATA = FALSE;
    }
}

void wdtdelay(unsigned long delay) {
    static unsigned long int dcount;
    for (dcount = 0; dcount <= delay; dcount++) { // delay a bit
        Nop();
        ClrWdt(); // reset the WDT timer
    };
}

void wdttime(unsigned long delay) // delay = ~ .05 seconds
{
    static unsigned long dcount, timetemp, clocks_hz;
    s_crit(HL);
    dcount = V.clock20;
    e_crit();
    clocks_hz = dcount + delay;

    do { // wait until delay
        s_crit(HL);
        timetemp = V.clock20;
        e_crit();
        ClrWdt();
    } while (timetemp < clocks_hz);
}

uint8_t checktime(unsigned long delay, uint8_t set) // delay = ~ .05 seconds
{
    static unsigned long dcount, timetemp, clocks_hz;

    if (set) {
        s_crit(HL);
        dcount = V.clock20;
        e_crit();
        clocks_hz = dcount + delay;
    }

    s_crit(HL);
    timetemp = V.clock20;
    e_crit();
    if (timetemp < clocks_hz) return FALSE;
    return TRUE;
}

uint8_t checktime_select(unsigned long delay, uint8_t set) // delay = ~ .05 seconds
{
    static unsigned long dcount, timetemp, clocks_hz;

    if (set) {
        s_crit(HL);
        dcount = V.clock20;
        e_crit();
        clocks_hz = dcount + delay;
    }

    s_crit(HL);
    timetemp = V.clock20;
    e_crit();
    if (timetemp < clocks_hz) return FALSE;
    return TRUE;
}

uint8_t checktime_motor(unsigned long delay, uint8_t set) // delay = ~ .05 seconds
{
    static unsigned long dcount, timetemp, clocks_hz;

    if (set) {
        s_crit(HL);
        dcount = V.clock20;
        e_crit();
        clocks_hz = dcount + delay;
    }

    s_crit(HL);
    timetemp = V.clock20;
    e_crit();
    if (timetemp < clocks_hz) return FALSE;
    return TRUE;
}

uint8_t checktime_cal(unsigned long delay, uint8_t set) // delay = ~ .05 seconds
{
    static unsigned long dcount, timetemp, clocks_hz;

    if (set) {
        s_crit(HL);
        dcount = V.clock20;
        e_crit();
        clocks_hz = dcount + delay;
    }

    s_crit(HL);
    timetemp = V.clock20;
    e_crit();
    if (timetemp < clocks_hz) return FALSE;
    return TRUE;
}

uint8_t checktime_eep(unsigned long delay, uint8_t set) // delay = ~ .05 seconds
{
    static unsigned long dcount, timetemp, clocks_hz;

    if (set) {
        s_crit(HL);
        dcount = V.clock20;
        e_crit();
        clocks_hz = dcount + delay;
    }

    s_crit(HL);
    timetemp = V.clock20;
    e_crit();
    if (timetemp < clocks_hz) return FALSE;
    return TRUE;
}

uint8_t checktime_track(unsigned long delay, uint8_t set) // delay = ~ .05 seconds
{
    static unsigned long dcount, timetemp, clocks_hz;

    if (set) {
        s_crit(HL);
        dcount = V.clock20;
        e_crit();
        clocks_hz = dcount + delay;
    }

    s_crit(HL);
    timetemp = V.clock20;
    e_crit();
    if (timetemp < clocks_hz) return FALSE;
    return TRUE;
}

void DelayFor18TCY(void) {
    static unsigned char n;
    _asm nop _endasm // asm code to disable compiler optimizations
    for (n = 0; n < lcd18; n++) Nop(); // works at 200 (slow white) or 24 (fast blue)
    //    lcdhits_18tcy++;
}

//------------------------------------------

void DelayPORXLCD(void) // works with 15
{
    Delay10KTCYx(15); // Delay of 15ms
    return;
}

//------------------------------------------

void DelayXLCD(void) // works with 5
{
    Delay10KTCYx(5); // Delay of 5ms
    return;
}

void putc2(unsigned char c) {
    while (Busy2USART()) {
    }; // wait until the usart is clear
    putc2USART(c);
}

void start_delay(void) {
    wdttime(BATRUNF); // wait for .5 seconds.
}

void clr_lcd() {
    if (!D_UPDATE) return;
    while (BusyXLCD());
}

/*	lp_filters
        0
        1
        2
        3	current
        4	currentin
        5	currentcharger
        6
        7
        8
 *	9
 */
float lp_filter(float new, int bn, int slow) // low pass filter, slow rate of change for new, LPCHANC channels, slow/fast select (1) to zero channel
{
    // smooth,lp_speed,lp_x is a udata global array to save stack space

    if (bn > LPCHANC)
        return new;
    if (slow) {
        lp_speed = 0.06;
    } else {
        lp_speed = 0.125;
    }
    lp_x = ((smooth[bn]*100.0) + (((new * 100.0)-(smooth[bn]*100.0)) * lp_speed)) / 100.0;
    smooth[bn] = lp_x;
    if (slow == (-1)) { // reset and return zero
        lp_x = 0.0;
        smooth[bn] = 0.0;
    }
    return lp_x;
}

void term_time(void) // sent internal time to rs-232 terminal
{
    ClrWdt(); // reset the WDT timer
    sprintf(termstr, " CT-%s", hms(V.timerint_count));
    puts2USART(termstr);
}

void hold_process(void) // hold the monitor in the current status until released.
{
    term_time();
    putrs2USART(hold0);
    YNKEY = WAIT_M;
    while (YNKEY == WAIT_M) {
        wdtdelay(10);
        ADC_read();
        idle_loop();
    }
    if (YNKEY == NO_M) {
        term_time();
        putrs2USART(hold1);
        return;
    }
    term_time();
    putrs2USART(hold1);
}

void system_data(void) // display system data on terminal
{
    static unsigned char z;
    ClrWdt(); // reset the WDT timer
    sprintf(bootstr2, "\r\n");
    puts2USART(bootstr2);
    term_time();
    putrs2USART(" FW ");
    strcpypgm2ram(bootstr2, build_time);
    puts2USART(bootstr2);
    putrs2USART(" ");
    strcpypgm2ram(bootstr2, build_date);
    puts2USART(bootstr2);
    strcpypgm2ram(bootstr2, MANDM_VERSION);
    puts2USART(bootstr2);
    sprintf(bootstr2,
            "\r\n Power status 1=OK %u, Config DIPSW %u%u%u%u%u%u%u%u, Temp Sensor %lu,Temp Comp %i\r\n Highint %lu, Lowint %lu, Critc Levels %i, HID Idle %i, ",
            PRIPOWEROK, DIPSW1, DIPSW2, DIPSW3, DIPSW4, DIPSW5, DIPSW6, DIPSW7, DIPSW8, R.thermo_batt, C.temp_drate, V.highint_count, V.lowint_count, (int) critc_level, (int) mode.idle);
    puts2USART(bootstr2);
    sprintf(bootstr2,
            "Timerint %lu, Workerint %lu, \r\n LCD display counts %lu, LCD 18tcy counts %lu, Com2int %lu, Bint %lu, Eint %lu, Aint %lu, Lowclocks %lu, Lowruns/S %lu, Timer4int %lu, TMR4 %i, qei_counts %i\r\n",
            V.timerint_count, V.worker_count, V.lcdhits, V.lcdhits_18tcy, V.c2_int, V.buttonint_count, V.eeprom_count, V.adc_count, V.clock20, V.clock20 / V.timerint_count, V.pwm4int_count, (int) TMR4, (int) V.qei_counts);
    puts2USART(bootstr2);

    sprintf(bootstr2,
            " Button int counts B3 %lu, B2 %lu, B1 %lu, B0 %lu : Motor Hunt Counts %lu, QEI position %li \r\n",
            V.b3, V.b2, V.b1, V.b0, V.hunt_count, qei1.c);
    puts2USART(bootstr2);

    for (z = 0; z < MAX_MOTOR; z++) {
        if (motordata[z].active) {
            sprintf(bootstr2,
                    " Motor #%i, MPos %4i MSet %4i ,Merror %4i , MHigh %4i MLow %4i MChange %4i , SPos %4i SSet %4i , SOffset %4i SSpan %4i ",
                    (int) z, motordata[z].pot.pos_actual, motordata[z].pot.pos_set, motordata[z].pot.error, motordata[z].pot.high, motordata[z].pot.low, motordata[z].pot.pos_change,
                    motordata[z].pot.scaled_actual, motordata[z].pot.scaled_set, motordata[z].pot.offset, motordata[z].pot.span);
            puts2USART(bootstr2);
            sprintf(bootstr2,
                    " SScale In %4i SScale out %4i \r\n",
                    (int) (motordata[z].pot.scale_in * 1000.0), (int) (motordata[z].pot.scale_out * 1000.0));
            puts2USART(bootstr2);
        }
    }
    ClrWdt(); // reset the WDT timer
}

void system_help(void) // display system help on terminal
{
    putrs2USART(keycmds0);
    putrs2USART(keycmds1);
}

char* hms(unsigned long sec) // convert long (seconds) to time string
{
    static unsigned long h = 0, m = 0, s = 0;

    if (sec > MAXSECONDS) sec = MAXSECONDS; // max time in seconds
    s = sec;
    h = (s / 3600);
    s = s - (h * 3600);
    m = (s / 60);
    s = s - (m * 60);
    sprintf(hms_string, "%01lu:%02lu:%02lu", h, m, s);
    return hms_string;
}

char* hm(unsigned long sec) // convert long (seconds) to time string
{
    static unsigned long h = 0, m = 0, s = 0;
    if (sec > MAXSECONDS) sec = MAXSECONDS; // max time in seconds
    s = sec;
    h = (s / 3600);
    s = s - (h * 3600);
    m = (s / 60);
    s = s - (m * 60);
    sprintf(hms_string, "%01lu:%02lu", h, m);
    return hms_string;
}

int ABSI(int i) {
    if (i < 0)
        return -i;
    else
        return i;
}

long ABSL(long i) {
    if (i < 0)
        return -i;
    else
        return i;
}

char* voltfp(unsigned long millvolts, char *strprt) // convert unsigned long (millvolts) to voltage string
{
    voltfrak = (float) millvolts / 1000;
    iw = (long) ((float) voltfrak);
    ip = (long) ((float) voltfrak * 100) - iw * 100;
    sprintf(strprt, "%d.%02d", (int) iw, (int) ip);
    return strprt;
}

char* voltfps(unsigned long millvolts, char *strprt) // convert unsigned long (millvolts) to voltage string (short)
{
    voltfrak = (float) millvolts / 1000;
    iw = (long) ((float) voltfrak);
    ip = (long) ((float) voltfrak * 10) - iw * 10;
    sprintf(strprt, "%d.%01d", (int) iw, (int) ip);
    return strprt;
}

char* voltfpi(long millvolts, char *strprt) // convert long (mill volts/watts/current) to string (integer with Kilo)
{
    sign = ' '; // init sign
    if (millvolts < 0)
        sign = '-';
    voltfrak = (float) millvolts / 1000;
    iw = (long) ((float) voltfrak);
    ip = (long) ((float) voltfrak * 10) - iw * 10;
    if (ABSL(iw) < 1500) {
        sprintf(strprt, "%c%li", sign, ABSL(iw));
    } else {
        voltfrak = voltfrak / 1000;
        iw = (long) ((float) voltfrak);
        ip = (long) ((float) voltfrak * 100) - iw * 100;
        sprintf(strprt, "%c%li.%02lik", sign, ABSL(iw), ABSL(ip));
    }
    return strprt;
}

char* ahfp(long millah, char *strprt) // convert long (.1 of Ah) to Ah string
{
    sign = ' '; // init sign
    if (millah < 0)
        sign = '-';
    ahfrak = (float) millah / 10;
    iw = (long) ((float) ahfrak);
    ip = (long) ((float) ahfrak * 10) - iw * 10;
    sprintf(strprt, "%c%d.%01d", sign, ABSI(iw), ABSI(ip));
    return strprt;
}

/*  prints messages from the alarm array, need a rework as it's buggy */
unsigned char check_alarm(unsigned char bn, const rom char* where) // print alarm codes to terminal or just the battery number with code 251
{ // or set flag with code 253 or clear flag code 252
    static unsigned char i = 0, alm_num = 255; // if bn is 255 return state of alarm_codes.alm_flag flag TRUE/FALSE, 254 return current alarm code
    s_crit(HL);

    if (bn > 250) {
        if (bn == 255) {
            if (alarm_codes.alm_flag) {
                e_crit();
                return TRUE;
            } else {
                e_crit();
                return FALSE;
            }
        }
        if (bn == 254) {
            e_crit();
            return alarm_buffer[almctr].alm_num;
        }
        if (bn == 253) {
            alarm_codes.alm_flag = TRUE;
            e_crit();
            return 253;
        }
        if (bn == 252) {
            alarm_codes.alm_flag = FALSE;
            e_crit();
            return 252;
        }
        if (bn == 251) {
            alarm_codes.alm_flag = FALSE;
            e_crit();
            return alarm_buffer[almctr].bn;
        }
    }

    if (alarm_codes.alm_flag == NULL0) { // nothing, lets go
        e_crit();
        return FALSE;
    }

    while (almctr > NULL0) {
        alm_num = alarm_buffer[--almctr].alm_num; // move down the alarm stack
        term_time();
        putrs2USART(where);
        sprintf(bootstr2, " Q%u, Battery %u,", almctr, alarm_buffer[almctr].bn); // use the message battery number if set
        puts2USART(bootstr2);
        i = 0; // set alarm index to zero
        if (alm_num == i++) putrs2USART(almcode0); //0
        if (alm_num == i++) putrs2USART(almcode1); //1
        if (alm_num == i++) putrs2USART(almcode2); //2
        if (alm_num == i++) putrs2USART(almcode3); //3
        if (alm_num == i++) putrs2USART(almcode4); //4
        if (alm_num == i++) putrs2USART(almcode5); //5
        if (alm_num == i++) putrs2USART(almcode6); //6
        if (alm_num == i++) putrs2USART(almcode7); //7
        if (alm_num == i++) putrs2USART(almcode8); //8
        if (alm_num == i++) putrs2USART(almcode9); //9
        if (alm_num == i++) putrs2USART(divert0); //10
        if (alm_num == i++) putrs2USART(divert1); //11
        if (alm_num == i++) putrs2USART(battbuffer0); //12
        if (alm_num == i++) putrs2USART(almcode10); //13
        if (alm_num == i++) putrs2USART(almcode11); //14
        if (alm_num == i++) putrs2USART(almcode12); //15
        if (alm_num == i++) putrs2USART(almcode13); //16
        if (alm_num == i++) putrs2USART(almcode14); //17
        if (alm_num == i++) putrs2USART(almcode15); //18
        if (alm_num == i++) putrs2USART(almcode16); //19
        if (alm_num == i++) putrs2USART(charger2); //20
        if (alm_num == i++) putrs2USART(charger3); //21
        if (alm_num == i++) putrs2USART(charger4); //22
        if (alm_num == i++) putrs2USART(almcode17); //23
        if ((alm_num > i) && (alm_num < 250)) { // if greater than last defined alarm code
            sprintf(bootstr2, " UNKNOWN Alarm code %u \r\n", alm_num);
            puts2USART(bootstr2);
        }
        if (almctr == NULL0) {
            alarm_codes.alm_flag = FALSE;
        }
        alarm_buffer[almctr].bn = 0; // set default battery number to zero
    };
    e_crit();
    return NULL0;
}

void fail_safe(void) {
    FAILSAFE = TRUE;
    while (DIPSW3 == HIGH) { // wait until switch is clear
        ADC_read();
        sprintf(bootstr2, "FS T%s,SV%lu             ", hms(V.timerint_count), R.systemvoltage / 100);
        LCD_VC_puts(VC0, DS0, YES);

        //	sprintf(bootstr2, "PV%lu,PI%li,CV%lu           ", R.inputvoltage / 100, R.currentin / 10, R.ccvoltage / 100);
        LCD_VC_puts(VC0, DS1, YES);

        //	sprintf(bootstr2, "B1V%lu,B2V%lu,LI%li                 ", R.primarypower[B1] / 100, R.primarypower[B2] / 100, C.currentload / 10);
        LCD_VC_puts(VC0, DS2, YES);

        sprintf(bootstr2, "%lu, %lu, %lu                  ", V.timerint_count, V.clock20, V.clock20 / V.timerint_count);
        LCD_VC_puts(VC0, DS3, YES);

        wdtdelay(5000);
        idle_loop();
    }
    FAILSAFE = FALSE;

}

void ansidraw(int mode) // tek 410x/ansi drawing stuff
{
    putc2(ESC);
    putc2('['); // clear screen
    putc2('2');
    putc2('J');
    putrs2USART(hello1);
    putrs2USART(hello0);
}

void update_lcd_menu(uint8_t menu_text_pos) {
    static unsigned char slow;
    static unsigned char position = 0;

    if (!mode.move) {
        if (mode.free) {
            strncpypgm2ram(bootstr2, menuselect_free[menu_text_pos], LCD_W); // show the selected menu text.
        } else {
            strncpypgm2ram(bootstr2, menuselect_track[menu_text_pos], LCD_W); // show the selected menu text.
        }
        mode.operate = menu_text_pos;
    } else {
        if (position != menu_text_pos) {
            mode.cal = FALSE;
            emotor_power_off();
            LED_1 = LOW;
            for (slow = 0; slow <= 10; slow++) {
                strncpypgm2ram(bootstr2, menutext + (slow + (menu_text_pos * 10)), LCD_W); // show the menu ribbon.
                LCD_VC_puts(dsi, DS0, YES);
                wdtdelay(10000);
            }
            position = menu_text_pos;
        } else {
            strncpypgm2ram(bootstr2, menutext + (10 + (menu_text_pos * 10)), LCD_W); // show the menu ribbon.
        }
    }
    LCD_VC_puts(dsi, DS0, YES);
    LCD_VC_puts(dsi, DS1, NO);
    LCD_VC_puts(dsi, DS2, NO);
    LCD_VC_puts(dsi, DS3, NO);
}

void Set_Cursor(void) {
    static unsigned char z, shape = 0, s_delay;

    for (z = 0; z < MAX_POT; z++) {
        Cursor[z] = 0b11111110; // blank
    }
    if (motordata[knob_to_pot].run || TEST_SPINNERS) {
        if (TEST_SPINNERS) {
            if (s_delay++ > 50) {
                if (++shape > MAX_SHAPES - 1) shape = 0;
                s_delay = 0;
            }
        } else {
            shape = knob_to_pot + 3;
        }
        Cursor[knob_to_pot] = spinners(shape, FALSE);
    } else {
        Cursor[knob_to_pot] = 0b11111111; // solid box
    }
}

void track_motor(void) { // move motor feedback pot/encoder to setpoint
    static float deadband = 0.0;
    static int was_running = FALSE, old_error = 0;
    unsigned char track_knob_to_pot,PERFECT=FALSE;
    uint8_t menu_pos;

    if (mode.free || mode.on_off_only || (mode.info_only)) return;

    track_knob_to_pot = knob_to_pot; // set the local version
    motordata[track_knob_to_pot].hunt_count = 0;
    checktime_track(TRACK_TIMEOUT, TRUE);
    if (motordata[track_knob_to_pot].pot.cal_failed) {
        if (!is_led_blinking(TEST_LED)) blink_led(TEST_LED, TRUE);
    } else {
        if (is_led_blinking(TEST_LED)) blink_led(TEST_LED, FALSE);
    }

    do { // move the assy/motor into the setting position
        check_cable(&menu_pos); // check DIPSW and set the menu_pos if needed
        if (menu_pos == cable_type) { // exit do loop if control cable is disconnected
            LED_3 = LOW;
            mode.free = TRUE;
            update_lcd_menu(menu_pos);
            return;
        }
        ADC_read();
        nav_menu();

        if (motordata[track_knob_to_pot].hunt_count > HUNT_MAX) { // adjust position deadband
            deadband = DEADB_HUNT;
        } else {
            if (motordata[track_knob_to_pot].run) {
                deadband = DEADB_RUN; // narrow deadband  when motor running
            } else {
                deadband = DEADB_STOP; // normal deadband when stopped
                if (knob2.movement != STOP) {
                    deadband = DEADB_KNOB;
                }
            }
        }

        if (mode.qei) { // shift gears in encoder mode
            if (ABSL(motordata[track_knob_to_pot].pot.error) > QEI_FAST) {
                if (DRIVE_V24 == LOW) {
                    POWER_X = LOW;
                    wdttime(RELAYRUNF); // wait for .5 seconds.
                    motordata[track_knob_to_pot].v24 = TRUE;
                    DRIVE_V24 = HIGH;
                    mode.v24 = TRUE;
                    putrs2USART("\x1b[7m 24 volt drive \x1b[0m\r\n");
                    POWER_X = HIGH;
                }
            } else {
                if (DRIVE_V24 == HIGH) {
                    POWER_X = LOW;
                    wdttime(RELAYRUNF); // wait for .5 seconds.
                    motordata[track_knob_to_pot].v24 = FALSE;
                    DRIVE_V24 = LOW;
                    mode.v24 = FALSE;
                    putrs2USART("\x1b[7m 5 volt drive \x1b[0m\r\n");
                    POWER_X = HIGH;
                }
            }
            if (ABSL(motordata[track_knob_to_pot].pot.error) > QEI_VERY_FAST) {
                if (POWER_S == LOW) {
                    if (DRIVE_V24 == HIGH) {
                        mode.slow_bypass = TRUE;
                        putrs2USART("\x1b[7m Slowing resistor is off \x1b[0m\r\n");
                        POWER_S = HIGH;
                    }
                }
            } else {
                if (POWER_S == HIGH) {
                    if (DRIVE_V24 == HIGH) {
                        mode.slow_bypass = FALSE;
                        putrs2USART("\x1b[7m Slowing resistor is on \x1b[0m\r\n");
                        POWER_S = LOW;
                    }
                }
            }
        }

        if ((motordata[track_knob_to_pot].pot.error > (int) ((float) TRACK_DB_L / deadband)) && (motordata[track_knob_to_pot].pot.error < (int) ((float) TRACK_DB_H / deadband))) {
            if (PERFECT && mode.qei) {
                if (was_running) {
                    deadband = DEADB_STOP; // normal deadband when stopped
                    sprintf(bootstr2, " In QEI deadband, Error %3i, SLOW Flag %1i, Total Hunts %i \r\n", motordata[track_knob_to_pot].pot.error, motordata[track_knob_to_pot].slow, motordata[track_knob_to_pot].hunt_count);
                    puts2USART(bootstr2);
                }
                motor_control(&motordata[track_knob_to_pot]);
                if (qei1.movement == STOP) {
                    motordata[track_knob_to_pot].run = FALSE;
                    if (was_running) {
                        deadband = DEADB_STOP; // normal deadband when stopped, so adjust it now
                        if (knob2.movement != STOP) {
                            deadband = DEADB_KNOB;
                        }
                        sprintf(bootstr2, " QEI stopped, Error %3i, SLOW Flag %1i, Total Hunts %i ", motordata[track_knob_to_pot].pot.error, motordata[track_knob_to_pot].slow, motordata[track_knob_to_pot].hunt_count);
                        puts2USART(bootstr2);
                        putrs2USART("\x1b[7m Motor Stopped. \x1b[0m\r\n");
                        was_running = FALSE;
                        LED_3 = LOW;
                    }
                }
            } else {
                motordata[track_knob_to_pot].run = FALSE;
                motor_control(&motordata[track_knob_to_pot]);
                if (was_running) {
                    deadband = DEADB_STOP; // normal deadband when stopped, so adjust it now
                    if (knob2.movement != STOP) {
                        deadband = DEADB_KNOB;
                    }
                    sprintf(bootstr2, " Error %3i, SLOW Flag %1i, Total Hunts %i ", motordata[track_knob_to_pot].pot.error, motordata[track_knob_to_pot].slow, motordata[track_knob_to_pot].hunt_count);
                    puts2USART(bootstr2);
                    putrs2USART("\x1b[7m Motor Stopped. \x1b[0m\r\n");
                    was_running = FALSE;
                    LED_3 = LOW;
                }
            }
        }

        if (motordata[track_knob_to_pot].pot.error > (int) ((float) TRACK_DB_H / deadband)) { // check knob position
            motordata[track_knob_to_pot].run = TRUE;
            was_running = TRUE;
            if (!motordata[track_knob_to_pot].cw) {
                motordata[track_knob_to_pot].hunt_count++;
                if (motordata[track_knob_to_pot].hunt_count > 1) V.hunt_count++;
            }
            motordata[track_knob_to_pot].cw = TRUE;
            LED_3 = HIGH;
            motor_control(&motordata[track_knob_to_pot]);
            if ((old_error != motordata[track_knob_to_pot].pot.error) && (ABSL(motordata[track_knob_to_pot].pot.error)>TRACK_DISPLAY)) {
                sprintf(bootstr2, " Error %3i, SLOW Flag %1i, Hunts %i ", motordata[track_knob_to_pot].pot.error, motordata[track_knob_to_pot].slow, motordata[track_knob_to_pot].hunt_count);
                puts2USART(bootstr2);
                putrs2USART("\x1b[7m Motor CW. \x1b[0m\r\n");
                old_error = motordata[track_knob_to_pot].pot.error;
            }
        }
        if (motordata[track_knob_to_pot].pot.error < (int) ((float) TRACK_DB_L / deadband)) { // check knob position
            motordata[track_knob_to_pot].run = TRUE;
            was_running = TRUE;
            motordata[track_knob_to_pot].cw = FALSE;
            LED_3 = HIGH;
            motor_control(&motordata[track_knob_to_pot]);
            if ((old_error != motordata[track_knob_to_pot].pot.error) && (ABSL(motordata[track_knob_to_pot].pot.error)>TRACK_DISPLAY)) {
                sprintf(bootstr2, " Error %3i, SLOW Flag %1i, Hunts %i ", motordata[track_knob_to_pot].pot.error, motordata[track_knob_to_pot].slow, motordata[track_knob_to_pot].hunt_count);
                puts2USART(bootstr2);
                putrs2USART("\x1b[7m Motor CCW. \x1b[0m\r\n");
                old_error = motordata[track_knob_to_pot].pot.error;
            }
        }
        if (motordata[track_knob_to_pot].hunt_count > HUNT_LOW) motordata[track_knob_to_pot].slow = TRUE;
        if (motordata[track_knob_to_pot].hunt_count > HUNT_HIGH) motordata[track_knob_to_pot].slow_only = TRUE;
    } while (motordata[track_knob_to_pot].run && !button.B0 && !button.B1 && !button.B2 && !checktime_track(TRACK_TIMEOUT, FALSE));
    if (mode.qei) {
        mode.slow_bypass = FALSE;
        DRIVE_V24 = LOW;
        mode.v24 = FALSE;
    }
    if (checktime_track(TRACK_TIMEOUT, FALSE)) {
        putrs2USART("\x1b[7m Motor movement TIMED OUT, setting knob position to motor position. \x1b[0m\r\n");
        if (mode.qei) knob2.c = qei1.c; // sync stopped position for timeout
        buzzer_ticks(1);
        voice2_ticks(50);
    }
    if (button.B0 || button.B1 || button.B2) {
        putrs2USART("\x1b[7m Motor movement Button Interrupt, setting knob position to motor position. \x1b[0m\r\n");
        if (mode.qei) knob2.c = qei1.c; // sync stopped position for INTERRUPT
        if (button.B0) {
            button.B0 = LOW;
            mode.free = TRUE;
            LED_3 = LOW;
        }
        buzzer_ticks(1);
        voice2_ticks(50);
    }
}

uint8_t check_cable(uint8_t *menu) { //adapter cables codes
    static uint8_t old_menu = 0xff, new_menu, check_menu;

    new_menu = ((DIPSW >> 4) & cable_type);
    if (new_menu == cable_type) { // check for disconnected cable code 0x07
        if (old_menu != cable_type) wdttime(4); // wait before recheck if it's a change from old_menu
        check_menu = ((DIPSW >> 4) & cable_type);
        if (new_menu == check_menu) { // double check
            if (old_menu != cable_type) { // jumper disconnected
                *menu = HELP_M; // select the help menu first after disconnect
                mode.operate = *menu;
                help_pos = 0;
                sprintf(bootstr2, "\r Cable Disconnected %i \r\n ", (int) check_menu);
                puts2USART(bootstr2);
                init_motordata(*menu);
            }
            if (mode.locked) {
                sprintf(bootstr2, "\r Menu selection was LOCKED \r\n ");
                puts2USART(bootstr2);
                old_menu = cable_type;
                *menu = HELP_M; // always update to help on true disconnect when unlocking
            }
            mode.locked = FALSE; // we can change the equipment mode
            return cable_type; // no cable connected OK to modify *menu
        } else {
            sprintf(bootstr2, "\r Disconnect Glitch!! Prev Cable Selection Code %i, New Cable Selection Code %i \r\n ", (int) old_menu, (int) check_menu);
            puts2USART(bootstr2);
            *menu = old_menu;
            return 0;
        }
    }

    if (old_menu != new_menu) {
        buzzer_ticks(3);
        wdttime(4); // wait and recheck
        check_menu = ((DIPSW >> 4) & cable_type);
        if (new_menu == check_menu) {
            *menu = new_menu; // after double check modify the menu selection
            mode.operate = *menu;
            help_pos = 0;
            sprintf(bootstr2, "\r Old Cable Selection Code %i, New Cable Selection Code %i \r\n ", (int) old_menu, (int) *menu);
            puts2USART(bootstr2);
            old_menu = *menu;
            init_motordata(*menu);
            if (!mode.locked) {
                sprintf(bootstr2, "\r Menu selection was UNLOCKED \r\n ");
                puts2USART(bootstr2);
            }
            mode.locked = TRUE; // equipment mode is locked, we can change the info screen
            return 0;
        } else {
            sprintf(bootstr2, "\r Selection Glitch!! Prev Cable Selection Code %i, New Cable Selection Code %i \r\n ", (int) old_menu, (int) check_menu);
            puts2USART(bootstr2);
            *menu = old_menu;
            return 0;
        }
    }
    *menu = old_menu;
    return 0;
}

/* basic user interface */
uint8_t get_hid(void) // mode is global
{
    static uint8_t menu_pos = HELP_M;
    static uint8_t get_out;

    if (!motordata[knob_to_pot].active) {
        get_out = 0;
        do {
            knob_to_pot++;
            if (knob_to_pot >= MAX_POT) knob_to_pot = 0;
            if (++get_out > MAX_POT + MAX_POT) continue; //    trouble in rivercity
        } while (!motordata[knob_to_pot].active);
        Set_Cursor();
    }

    if (button.B1) {
        LED_2 = HIGH;
        get_out = 0;
        do {
            knob_to_pot++;
            if (knob_to_pot >= MAX_POT) knob_to_pot = 0;
            if (++get_out > MAX_POT + MAX_POT) continue; //    trouble in rivercity
        } while (!motordata[knob_to_pot].active);

        Set_Cursor();
        term_time();
        sprintf(bootstr2, " knob_to_pot  %u ", (int) knob_to_pot);
        puts2USART(bootstr2);
        putrs2USART("\x1b[7m Mode Button 2. \x1b[0m\r\n");
        LED_2 = LOW;
        button.B1 = FALSE;
    }

    //    check_cable(&menu_pos); // check DIPSW and set the menu_pos if needed
    if (button.B0 || (checktime_select(SELECT_ACTION, FALSE) && mode.move)) {
        if (!mode.move) mode.free = !mode.free; // toggle the motor tracking mode
        term_time();
        sprintf(bootstr2, " menu_pos  %u ", (int) menu_pos);
        puts2USART(bootstr2);
        putrs2USART("\x1b[7m Mode Button 1. \x1b[0m\r\n");
        mode.move = FALSE; // switch modes with button 1 presses
        button.B0 = FALSE;
        LED_0 = LOW;
    } else {
        if (knob1.movement != STOP) { // do we have knob motion
            if (checktime(MENU_ACTION, FALSE)) { // is knob still moving and not stopped
                checktime_select(SELECT_ACTION, TRUE); // keep resetting the select timer
                mode.move = TRUE;
                LED_0 = HIGH;
                if ((knob1.movement == CW) && (ABSL(knob1.band) > MENU_BAND)) { // turning clockwise
                    mode.move = TRUE;
                    LED_0 = LOW;
                    if (!mode.locked) {
                        menu_pos++; // if the cable is open allow changes
                        checktime(MENU_ACTION, TRUE); // reset the movement timer
                        if (menu_pos >= MAX_MENU) menu_pos = 0;
                        init_motordata(menu_pos);
                        buzzer_ticks(1);
                        term_time();
                        sprintf(bootstr2, " menu_pos  %u ", (int) menu_pos);
                        puts2USART(bootstr2);
                        putrs2USART("\x1b[7m Menu Right. \x1b[0m\r\n");
                    } else {
                        help_pos++; // if the cable is open allow changes
                        checktime(MENU_ACTION, TRUE); // reset the movement timer
                        if (help_pos >= MAX_HELP) help_pos = 0;
                        //                        init_motordata(menu_pos);
                        term_time();
                        sprintf(bootstr2, " help_pos  %u ", (int) help_pos);
                        puts2USART(bootstr2);
                        putrs2USART("\x1b[7m Help Right. \x1b[0m\r\n");
                    }
                } else { // CCW
                    if (ABSL(knob1.band) > MENU_BAND) { // turning counter-clockwise
                        mode.move = TRUE;
                        LED_0 = LOW;
                        if (!mode.locked) {
                            menu_pos--; // allow changes
                            checktime(MENU_ACTION, TRUE); // reset the movement timer
                            if (menu_pos >= MAX_MENU) menu_pos = MAX_MENU - 1;
                            init_motordata(menu_pos);
                            buzzer_ticks(1);
                            term_time();
                            sprintf(bootstr2, " menu_pos  %u ", (int) menu_pos);
                            puts2USART(bootstr2);
                            putrs2USART("\x1b[7m Menu Left. \x1b[0m\r\n");
                        } else {
                            help_pos++; // allow changes
                            checktime(MENU_ACTION, TRUE); // reset the movement timer
                            if (help_pos >= MAX_HELP) help_pos = 0;
                            //                           init_motordata(menu_pos);
                            term_time();
                            sprintf(bootstr2, " help_pos  %u ", (int) help_pos);
                            puts2USART(bootstr2);
                            putrs2USART("\x1b[7m Help Left. \x1b[0m\r\n");
                        }
                    }
                }
                LED_0 = HIGH;
            }
        } else {
            checktime(MENU_ACTION, TRUE); // reset the movement timer
        }
    }
    if (mode.move) {
        LED_0 = HIGH; // update mode led
    } else {
        LED_0 = LOW; // update mode led
    }

    if (!mode.info_only) {
        if (mode.free || mode.on_off_only) {
            if (is_led_blinking(TEST_LED)) blink_led(TEST_LED, FALSE);
            if (knob2.movement != STOP) { // do we have knob motion
                if (checktime_motor(MOTOR_ACTION, FALSE)) { // is knob still moving and not stopped
                    LED_2 = HIGH;
                    if ((knob2.movement == CW) && (knob2.band > MOTOR_BAND)) { // turning clockwise
                        motordata[knob_to_pot].run = TRUE;
                        motordata[knob_to_pot].cw = TRUE;
                        motor_control(&motordata[knob_to_pot]);
                        checktime_motor(MOTOR_ACTION, TRUE); // reset the movement timer
                        term_time();
                        sprintf(bootstr2, " Motor Number  %u ", (int) knob_to_pot);
                        puts2USART(bootstr2);
                        putrs2USART("\x1b[7m Motor CW. \x1b[0m\r\n");
                    } else { // CCW
                        if (ABSL(knob2.band) > MOTOR_BAND) { // turning counter-clockwise
                            motordata[knob_to_pot].run = TRUE;
                            motordata[knob_to_pot].cw = FALSE;
                            motor_control(&motordata[knob_to_pot]);
                            checktime_motor(MOTOR_ACTION, TRUE); // reset the movement timer
                            term_time();
                            sprintf(bootstr2, " Motor Number  %u ", (int) knob_to_pot);
                            puts2USART(bootstr2);
                            putrs2USART("\x1b[7m Motor CCW. \x1b[0m\r\n");
                        }
                    }
                }
            } else {
                if (!mode.on_off_only) { // stop motion with no POT movement
                    motordata[knob_to_pot].run = FALSE;
                    motordata[knob_to_pot].cw = TRUE;
                    motor_control(&motordata[knob_to_pot]);
                } else {
                    motordata[knob_to_pot].run = FALSE;
                }
                checktime_motor(MOTOR_ACTION, TRUE); // reset the movement timer
                LED_2 = LOW;
            }
        } else { // track motor to postion pot
            track_motor();
        }
    }

    if (mode.free) {
        if (!is_led_blinking(MENU_LED)) blink_led(MENU_LED, TRUE);
    } else {
        if (is_led_blinking(MENU_LED)) blink_led(MENU_LED, FALSE);
    }
    return menu_pos;
}

/* assembly selection */
void nav_menu(void) {
    Set_Cursor();
    switch (mode.operate) {
        case VIISION_M:
            viision_m_display();
            break;
        case E220E500_M:
            e220_m_display();
            break;
        case E220E500_E:
            e220_qei_display();
            break;
        case GSD_M:
            gsd_m_display();
            break;
        case VIISION_MS:
            viision_ms_display();
            break;
        case VARIAN_V:
            varian_v_display();
            break;
        case HELP_M:
            help_m_display();
            break;
        default:
            default_display();
            break;
    }
}

void e220_qei_exer(unsigned char times) {
    unsigned char z;
    emotor_power_off(); // turn off the power first
    if (mode.free || motordata[0].pot.cal_failed) return; // only use when tracking is enabled.
    mode.v24 = FALSE;
    if (qei1.max == 0) return;
    for (z = 0; z <= times; z++) {
        sprintf(bootstr2, " Motor encoder exerciser loop # %i\r\n", (int) z);
        puts2USART(bootstr2);
        knob2.c = (long) ((float) qei1.max * 0.01);
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.666);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.333);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.9);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.1);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.5);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        if (button.B0 || button.B1 || button.B2) break;
    }
    Clear_All_Buttons();
    mode.v24 = FALSE;
    emotor_power_off(); // turn off the power first
    wdttime(RELAYRUNF); // wait for .5 seconds.
}

/* assembly selection */
void exerciser(void) {
    Set_Cursor();
    switch (mode.operate) {
        case VIISION_M:
            viision_m_display();
            break;
        case E220E500_M:
            e220_m_display();
            break;
        case E220E500_E:
            e220_qei_exer(10);
            break;
        case GSD_M:
            gsd_m_display();
            break;
        case VIISION_MS:
            viision_ms_display();
            break;
        case VARIAN_V:
            varian_v_display();
            break;
        case HELP_M:
            help_m_display();
            break;
        default:
            default_display();
            break;
    }
}

/* main HID loop */
void hid_menu(void) {
    static uint8_t menu_pos = HELP_M;

    menu_pos = get_hid();
    check_cable(&menu_pos);
    update_lcd_menu(menu_pos);
    nav_menu();
}

/* disconnect help screen */
void help_m_display(void) {
    if (help_pos == 0) {
        sprintf(bootstr2, "%cConnect Adapter to ", Cursor[0]);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "%cModule. Press Test ", Cursor[1]);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "%cButton to Calibrate", Cursor[2]);
        LCD_VC_puts(VC0, DS3, YES);
    } else {
        sprintf(bootstr2, "                     ");
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void gsd_m_display(void) {
    if (help_pos == 0) {
        sprintf(bootstr2, "%cA%2i Set%2i V%2li I%2li               ", Cursor[0], motordata[0].pot.scaled_actual / 10, motordata[0].pot.scaled_set / 10, R.pos_x / 10, R.current_x);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "Move Cable to Axis              ");
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "Press Cal Button            ");
        LCD_VC_puts(VC0, DS3, YES);
    } else {
        sprintf(bootstr2, "                     ");
        if (motordata[0].active) sprintf(bootstr2, "A Pot%2i O%2i S%2i C%2i               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.offset / 10, motordata[0].pot.span / 10, motordata[0].pot.pos_change);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i O%2i S%2i C%2i               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.offset / 10, motordata[1].pot.span / 10, motordata[1].pot.pos_change);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i O%2i S%2i C%2i               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.offset / 10, motordata[2].pot.span / 10, motordata[2].pot.pos_change);
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void e220_m_display(void) {
    if (help_pos == 0) {
        sprintf(bootstr2, "%cX%2i Set%2i V%2li I%2li               ", Cursor[0], motordata[0].pot.scaled_actual / 10, motordata[0].pot.scaled_set / 10, R.pos_x / 10, R.current_x);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "%cY%2i Set%2i V%2li I%2li               ", Cursor[1], motordata[1].pot.scaled_actual / 10, motordata[1].pot.scaled_set / 10, R.pos_y / 10, R.current_y);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "%cZ%2i Set%2i V%2li I%2li               ", Cursor[2], motordata[2].pot.scaled_actual / 10, motordata[2].pot.scaled_set / 10, R.pos_z / 10, R.current_z);
        LCD_VC_puts(VC0, DS3, YES);
    } else {
        sprintf(bootstr2, "                     ");
        if (motordata[0].active) sprintf(bootstr2, "X Pot%2i O%2i S%2i C%2i               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.offset / 10, motordata[0].pot.span / 10, motordata[0].pot.pos_change);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i O%2i S%2i C%2i               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.offset / 10, motordata[1].pot.span / 10, motordata[1].pot.pos_change);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i O%2i S%2i C%2i               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.offset / 10, motordata[2].pot.span / 10, motordata[2].pot.pos_change);
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void viision_m_display(void) {
    if (help_pos == 0) {
        sprintf(bootstr2, "%cX%2i Set%2i V%2li I%2li               ", Cursor[0], motordata[0].pot.scaled_actual / 10, motordata[0].pot.scaled_set / 10, R.pos_x / 10, R.current_x);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "%cNO Y or TILT AXIS    ", Cursor[1]); // info display data
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "%cZ%2i Set%2i V%2li I%2li               ", Cursor[2], motordata[2].pot.scaled_actual / 10, motordata[2].pot.scaled_set / 10, R.pos_z / 10, R.current_z);
        LCD_VC_puts(VC0, DS3, YES);
    } else {
        sprintf(bootstr2, "                     ");
        if (motordata[0].active) sprintf(bootstr2, "X Pot%2i O%2i S%2i C%2i               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.offset / 10, motordata[0].pot.span / 10, motordata[0].pot.pos_change);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i O%2i S%2i C%2i               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.offset / 10, motordata[1].pot.span / 10, motordata[1].pot.pos_change);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i O%2i S%2i C%2i               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.offset / 10, motordata[2].pot.span / 10, motordata[2].pot.pos_change);
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void viision_ms_display(void) {
    if (help_pos == 0) {
        sprintf(bootstr2, "                    "); // info display data
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "%cR%2i Set%2i V%2li I%2li               ", Cursor[1], motordata[1].pot.scaled_actual / 10, motordata[1].pot.scaled_set / 10, R.pos_y / 10, R.current_y);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                    "); // info display data
        LCD_VC_puts(VC0, DS3, YES);
    } else {
        sprintf(bootstr2, "                     ");
        if (motordata[0].active) sprintf(bootstr2, "X Pot%2i O%2i S%2i C%2i               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.offset / 10, motordata[0].pot.span / 10, motordata[0].pot.pos_change);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i O%2i S%2i C%2i               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.offset / 10, motordata[1].pot.span / 10, motordata[1].pot.pos_change);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i O%2i S%2i C%2i               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.offset / 10, motordata[2].pot.span / 10, motordata[2].pot.pos_change);
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void e220_qei_display(void) {
    if (help_pos == 0) {
        sprintf(bootstr2, "%cR%2li S%2li E%2i               ", Cursor[0], qei1.c, knob2.c, motordata[0].pot.error);
        LCD_VC_puts(VC0, DS1, YES);
        if (motordata[0].run) {
            sprintf(bootstr2, " Motor direction %i                   ", (int) motordata[0].cw); // info display data
            LCD_VC_puts(VC0, DS2, YES);
            sprintf(bootstr2, " Movement %li                   ", qei1.band); // info display data
            LCD_VC_puts(VC0, DS3, YES);
        } else {
            sprintf(bootstr2, "                    "); // info display data
            LCD_VC_puts(VC0, DS2, YES);
            sprintf(bootstr2, "                    "); // info display data
            LCD_VC_puts(VC0, DS3, YES);
        }
    } else {
        sprintf(bootstr2, "                     ");
        if (motordata[0].active) sprintf(bootstr2, "X Pot%2i O%2i S%2i C%2i               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.offset / 10, motordata[0].pot.span / 10, motordata[0].pot.pos_change);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i O%2i S%2i C%2i               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.offset / 10, motordata[1].pot.span / 10, motordata[1].pot.pos_change);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i O%2i S%2i C%2i               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.offset / 10, motordata[2].pot.span / 10, motordata[2].pot.pos_change);
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void default_display(void) {
    if (help_pos == 0) {
        sprintf(bootstr2, " Nothing to see here ");
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, " Move                "); // info display data
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, " Along               "); // info display data
        LCD_VC_puts(VC0, DS3, YES);
    } else {
        sprintf(bootstr2, "                     ");
        if (motordata[0].active) sprintf(bootstr2, "X Pot%2i O%2i S%2i C%2i               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.offset / 10, motordata[0].pot.span / 10, motordata[0].pot.pos_change);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i O%2i S%2i C%2i               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.offset / 10, motordata[1].pot.span / 10, motordata[1].pot.pos_change);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i O%2i S%2i C%2i               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.offset / 10, motordata[2].pot.span / 10, motordata[2].pot.pos_change);
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void varian_v_display(void) { // Open SW on Z pot, Closed SW on X POT, Y POT is not used
    if (help_pos == 0) {
        sprintf(bootstr2, "                     "); // info display data
        if (motordata[2].pot.pos_actual < 100) sprintf(bootstr2, " Open  SW =%2i MADE           ", motordata[2].pot.pos_actual / 10);
        LCD_VC_puts(VC0, DS1, YES);
        if (!POWER_Y) {
            sprintf(bootstr2, "%c OPEN  SW %2i               ", Cursor[1], motordata[2].pot.pos_actual / 10);
        } else {
            sprintf(bootstr2, "%c CLOSE SW %2i               ", Cursor[1], motordata[0].pot.pos_actual / 10);
        }
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     "); // info display data
        if (motordata[0].pot.pos_actual < 100) sprintf(bootstr2, " Close SW =%2i MADE          ", motordata[0].pot.pos_actual / 10);
        LCD_VC_puts(VC0, DS3, YES);
    } else {
        sprintf(bootstr2, "                     ");
        if (motordata[0].active) sprintf(bootstr2, "X Pot%2i O%2i S%2i C%2i               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.offset / 10, motordata[0].pot.span / 10, motordata[0].pot.pos_change);
        LCD_VC_puts(VC0, DS1, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i O%2i S%2i C%2i               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.offset / 10, motordata[1].pot.span / 10, motordata[1].pot.pos_change);
        LCD_VC_puts(VC0, DS2, YES);
        sprintf(bootstr2, "                     ");
        if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i O%2i S%2i C%2i               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.offset / 10, motordata[2].pot.span / 10, motordata[2].pot.pos_change);
        LCD_VC_puts(VC0, DS3, YES);
    }
}

void fail_all_motors(uint8_t fail) {
    int z;
    for (z = 0; z < MAX_MOTOR; z++) { // set or clear the motor cal failed flag
        motordata[z].pot.cal_failed = fail;
    }
}

/* assembly calibration and test routines */
void run_cal(void) // routines to test and set position data for assy motors or valves
{
    unsigned long z, motor_counts = 1000;
    long qei1_tmp = 0;
    char p = 'X';
    int test_counts, STOPPED = FALSE;

    mode.cal = FALSE;
    ADC_read();
    ADC_read();
    button.B2 = 0;
    help_pos = 0;
    init_motordata(mode.operate);
    if (mode.info_only) {
        LED_1 = LOW;
        mode.free = FALSE;
        mode.v24 = FALSE;
        return;
    }
    putrs2USART("\x1b[7m Calibrate/Test Assy(s). \x1b[0m\r\n");
    if (mode.operate == GSD_M) motor_counts = 2000;
    mode.free = TRUE;
    if (motordata[0].v24 == TRUE) mode.v24 = TRUE;
    emotor_power_off();
    wdttime(RELAYRUNF); // wait for .5 seconds.
    if (mode.operate == VIISION_M) motor_counts *= 2;
    fail_all_motors(FALSE); // clear the failed flag on all motors
    emotor_power_on();
    checktime_cal(motor_counts, TRUE);
    z = 0;

    if (!mode.qei) { // analog and switch cals
        /* valve/ON/CLOSED with switch feedback tests */
        if (mode.operate == VARIAN_V) {
            for (test_counts = 0; test_counts <= 1; test_counts++) {
                motor_counts = 100;
                checktime_cal(motor_counts, TRUE);
                emotor_power_on();
                z = 0;
                do {
                    emotor_v24(mode.v24);
                    if (z % 2000 == 0) {
                        if (button.B2 == 1) {
                            emotor_power_off();
                            fail_all_motors(TRUE);
                            Clear_All_Buttons();
                            wdttime(RELAYRUN); // wait for .5 seconds.
                            LED_1 = LOW;
                            mode.free = TRUE;
                            mode.v24 = FALSE;
                            emotor_v24(mode.v24);
                            init_motordata(mode.operate);
                            putrs2USART("\x1b[7m Calibrate/Test Completed, Failed. \x1b[0m\r\n");
                            return;
                        }
                        display_cal();
                        sprintf(bootstr2, "Cal: Valve Open %i         ", test_counts); // info display data
                        LCD_VC_puts(dsi, DS0, YES);
                        sprintf(bootstr2, " Open SW =%2i                             ", motordata[2].pot.pos_actual / 10);
                        if (motordata[2].pot.pos_actual < 100) sprintf(bootstr2, " Open SW =%2i  MADE           ", motordata[2].pot.pos_actual / 10);
                        LCD_VC_puts(VC0, DS1, YES);
                        sprintf(bootstr2, " Valve Testing ON                      ");
                        LCD_VC_puts(VC0, DS2, YES);
                        sprintf(bootstr2, " Close SW =%2i                              ", motordata[0].pot.pos_actual / 10);
                        if (motordata[0].pot.pos_actual < 100) sprintf(bootstr2, " Close SW =%2i MADE          ", motordata[0].pot.pos_actual / 10);
                        LCD_VC_puts(VC0, DS3, YES);
                    }
                    z++;
                } while (!checktime_cal(motor_counts, FALSE));
                if (motordata[2].pot.pos_actual < 100 && motordata[0].pot.pos_actual > 400) motordata[1].pot.cal_high = TRUE;
                if (motordata[0].pot.pos_actual < 100) motordata[1].pot.cal_low = FALSE;
                checktime_cal(motor_counts, TRUE);
                emotor_power_off(); // turn off the power first
                z = 0;
                do {
                    emotor_v24(mode.v24);
                    if (z % 2000 == 0) {
                        if (button.B2 == 1) {
                            emotor_power_off();
                            fail_all_motors(TRUE);
                            Clear_All_Buttons();
                            wdttime(RELAYRUN); // wait for .5 seconds.
                            LED_1 = LOW;
                            mode.free = TRUE;
                            mode.v24 = FALSE;
                            emotor_v24(mode.v24);
                            init_motordata(mode.operate);
                            putrs2USART("\x1b[7m Calibrate/Test Completed, Failed. \x1b[0m\r\n");
                            return;
                        }
                        display_cal();
                        sprintf(bootstr2, "Cal: Valve Closed %i      ", test_counts); // info display data
                        LCD_VC_puts(dsi, DS0, YES);
                        sprintf(bootstr2, " Open SW =%2i                             ", motordata[2].pot.pos_actual / 10);
                        if (motordata[2].pot.pos_actual < 100) sprintf(bootstr2, " Open SW =%2i  MADE           ", motordata[2].pot.pos_actual / 10);
                        LCD_VC_puts(VC0, DS1, YES);
                        sprintf(bootstr2, " Valve Testing OFF                        ");
                        LCD_VC_puts(VC0, DS2, YES);
                        sprintf(bootstr2, " Close SW =%2i                              ", motordata[0].pot.pos_actual / 10);
                        if (motordata[0].pot.pos_actual < 100) sprintf(bootstr2, " Close SW =%2i MADE          ", motordata[0].pot.pos_actual / 10);
                        LCD_VC_puts(VC0, DS3, YES);
                    }
                    z++;
                } while (!checktime_cal(motor_counts, FALSE));
                if (motordata[0].pot.pos_actual < 100 && motordata[2].pot.pos_actual > 400) motordata[1].pot.cal_low = TRUE;
                if (motordata[2].pot.pos_actual < 100) motordata[1].pot.cal_high = FALSE;
            }
            LED_1 = LOW;
            mode.free = FALSE;
            mode.v24 = FALSE;
            if (!(motordata[1].pot.cal_low && motordata[1].pot.cal_high)) {
                if (motordata[1].active) {
                    button.B2 = FALSE;
                    p = 'X' + (char) 1;
                    sprintf(bootstr2, "Valve failed calibration %c    ", p); // info display data
                    LCD_VC_puts(dsi, DS0, YES);
                    sprintf(bootstr2, "Open %i Close %i      ", motordata[1].pot.cal_high, motordata[1].pot.cal_low);
                    LCD_VC_puts(VC0, DS1, YES);
                    sprintf(bootstr2, "                      ");
                    if (!motordata[1].pot.cal_high) sprintf(bootstr2, "Open Switch FAILED         ");
                    LCD_VC_puts(VC0, DS2, YES);
                    sprintf(bootstr2, "                      ");
                    if (!motordata[1].pot.cal_low) sprintf(bootstr2, "Closed Switch FAILED         ");
                    LCD_VC_puts(VC0, DS3, YES);
                    blink_led(TEST_LED, TRUE);
                    do {
                        buzzer_ticks(2);
                        ClrWdt();
                    } while (button.B2 == FALSE);
                    blink_led(TEST_LED, FALSE);
                    emotor_power_off();
                    fail_all_motors(TRUE);
                    Clear_All_Buttons();
                    wdttime(RELAYRUN); // wait for .5 seconds.
                    LED_1 = LOW;
                    mode.free = TRUE;
                    mode.v24 = FALSE;
                    emotor_v24(mode.v24);
                    init_motordata(mode.operate);
                }
            }
            putrs2USART("\x1b[7m Calibrate/Test Completed. \x1b[0m\r\n");
            return;
        } // end of valve calibration tests

        /* normal motor tests */
        STOPPED = FALSE;
        Reset_Change_Count();
        do {
            emotor_v24(mode.v24);
            if (z % 2000 == 0) {
                if (Change_Count()) {
                    sprintf(bootstr2, " X Y Z change %li,%li,%li \r\n", ABSL(R.pos_x - R.change_x), ABSL(R.pos_y - R.change_y), ABSL(R.pos_z - R.change_z));
                    puts2USART(bootstr2);
                    if (R.stable_x && R.stable_y && R.stable_z) {
                        if (mode.operate != VIISION_M) STOPPED = TRUE;
                        sprintf(bootstr2, " NO ADC VOLTAGE CHANGE DETECTED \r\n\r\n");
                        puts2USART(bootstr2);
                    }
                    Reset_Change_Count();
                }
                if (button.B2 == 1) {
                    emotor_power_off();
                    fail_all_motors(TRUE);
                    Clear_All_Buttons();
                    wdttime(RELAYRUN); // wait for .5 seconds.
                    LED_1 = LOW;
                    mode.free = TRUE;
                    mode.v24 = FALSE;
                    emotor_v24(mode.v24);
                    init_motordata(mode.operate);
                    putrs2USART("\x1b[7m Calibrate/Test Completed, Failed. \x1b[0m\r\n");
                    return;
                }
                display_cal();
                sprintf(bootstr2, "Calibrate CW %lu      ", z); // info display data
                LCD_VC_puts(dsi, DS0, YES);
                sprintf(bootstr2, "                     ");
                if (motordata[0].active) sprintf(bootstr2, "X Pot%2i D%2i S%2i I%2li               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.scaled_actual / 10, motordata[0].pot.span / 10, R.current_x);
                LCD_VC_puts(VC0, DS1, YES);
                sprintf(bootstr2, "                     ");
                if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i D%2i S%2i I%2li               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.scaled_actual / 10, motordata[1].pot.span / 10, R.current_y);
                LCD_VC_puts(VC0, DS2, YES);
                sprintf(bootstr2, "                     ");
                if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i D%2i S%2i I%2li               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.scaled_actual / 10, motordata[2].pot.span / 10, R.current_z);
                LCD_VC_puts(VC0, DS3, YES);
            }
            z++;
        } while (!checktime_cal(motor_counts, FALSE) && !STOPPED);

        emotor_power_off(); // turn off the power first
        wdttime(RELAYRUN); // wait for .5 seconds.
        emotor_switch_ccw(); // switch to CCW
        wdttime(RELAYRUNF); // wait for .5 seconds.
        STOPPED = FALSE;

        if (mode.operate != VIISION_M) {
            emotor_power_on();
            checktime_cal(motor_counts, TRUE);
            z = 0;
            Reset_Change_Count();
            do {
                emotor_v24(mode.v24);
                if (z % 2000 == 0) {
                    if (Change_Count()) {
                        sprintf(bootstr2, " X Y Z change %li,%li,%li \r\n", ABSL(R.pos_x - R.change_x), ABSL(R.pos_y - R.change_y), ABSL(R.pos_z - R.change_z));
                        puts2USART(bootstr2);
                        if (R.stable_x && R.stable_y && R.stable_z) {
                            if (mode.operate != VIISION_M) STOPPED = TRUE;
                            sprintf(bootstr2, " NO ADC VOLTAGE CHANGE DETECTED \r\n\r\n");
                            puts2USART(bootstr2);
                        }
                        Reset_Change_Count();
                    }
                    if (button.B2 == 1) {
                        emotor_power_off();
                        fail_all_motors(TRUE);
                        Clear_All_Buttons();
                        wdttime(RELAYRUN); // wait for .5 seconds.
                        LED_1 = LOW;
                        mode.free = TRUE;
                        mode.v24 = FALSE;
                        emotor_v24(mode.v24);
                        init_motordata(mode.operate);
                        putrs2USART("\x1b[7m Calibrate/Test Completed, Failed. \x1b[0m\r\n");
                        return;
                    }
                    display_cal();
                    sprintf(bootstr2, "Calibrate CCW %lu      ", z); // info display data
                    LCD_VC_puts(dsi, DS0, YES);
                    sprintf(bootstr2, "                     ");
                    if (motordata[0].active) sprintf(bootstr2, "X Pot%2i D%2i S%2i I%2li               ", motordata[0].pot.pos_actual / 10, motordata[0].pot.scaled_actual / 10, motordata[0].pot.span / 10, R.current_x);
                    LCD_VC_puts(VC0, DS1, YES);
                    sprintf(bootstr2, "                     ");
                    if (motordata[1].active) sprintf(bootstr2, "Y Pot%2i D%2i S%2i I%2li               ", motordata[1].pot.pos_actual / 10, motordata[1].pot.scaled_actual / 10, motordata[1].pot.span / 10, R.current_y);
                    LCD_VC_puts(VC0, DS2, YES);
                    sprintf(bootstr2, "                     ");
                    if (motordata[2].active) sprintf(bootstr2, "Z Pot%2i D%2i S%2i I%2li               ", motordata[2].pot.pos_actual / 10, motordata[2].pot.scaled_actual / 10, motordata[2].pot.span / 10, R.current_z);
                    LCD_VC_puts(VC0, DS3, YES);
                }
                z++;
            } while (!checktime_cal(motor_counts, FALSE) && !STOPPED);
        }
    } else { // qei mode cals
        qei1.c = 0;
        qei1_tmp = qei1.c;
        emotor_power_on();
        wdttime(20); // wait
        for (z = 0; z < 990; z++) {
            sprintf(bootstr2, "Calibrate CW %lu      ", z); // info display data
            LCD_VC_puts(dsi, DS0, YES);
            sprintf(bootstr2, "                     ");
            if (motordata[0].active) sprintf(bootstr2, " Motor counts %2li               ", qei1.c);
            LCD_VC_puts(VC0, DS1, YES);
            sprintf(bootstr2, "                     ");
            LCD_VC_puts(VC0, DS2, YES);
            LCD_VC_puts(VC0, DS3, YES);
            wdttime(1); // wait
            if (z % 25 == 0) {
                if (qei1_tmp == qei1.c) z = 1000;
                qei1_tmp = qei1.c;
            }
            if (button.B2) {
                emotor_power_off();
                fail_all_motors(TRUE);
                Clear_All_Buttons();
                wdttime(RELAYRUN); // wait for .5 seconds.
                LED_1 = LOW;
                mode.free = TRUE;
                mode.v24 = FALSE;
                emotor_v24(mode.v24);
                init_motordata(mode.operate);
                putrs2USART("\x1b[7m Calibrate/Test Completed, Failed. \x1b[0m\r\n");
                return;
            }
        }
        emotor_power_off(); // turn off the power first
        wdttime(RELAYRUN); // wait for .5 seconds.
        emotor_switch_ccw(); // switch to CCW
        wdttime(RELAYRUNF); // wait for .5 seconds.
        qei1.c = 0;
        qei1_tmp = qei1.c;
        emotor_power_on();
        wdttime(20); // wait
        for (z = 0; z < 990; z++) {
            sprintf(bootstr2, "Calibrate CCW %lu      ", z); // info display data
            LCD_VC_puts(dsi, DS0, YES);
            sprintf(bootstr2, "                     ");
            if (motordata[0].active) sprintf(bootstr2, " Motor counts %2li               ", qei1.c);
            LCD_VC_puts(VC0, DS1, YES);
            sprintf(bootstr2, "                     ");
            LCD_VC_puts(VC0, DS2, YES);
            LCD_VC_puts(VC0, DS3, YES);
            wdttime(1); // wait
            if (z % 25 == 0) {
                if (qei1_tmp == qei1.c) z = 1000;
                qei1_tmp = qei1.c;
            }
            if (button.B2) {
                emotor_power_off();
                fail_all_motors(TRUE);
                Clear_All_Buttons();
                wdttime(RELAYRUN); // wait for .5 seconds.
                LED_1 = LOW;
                mode.free = TRUE;
                mode.v24 = FALSE;
                emotor_v24(mode.v24);
                init_motordata(mode.operate);
                putrs2USART("\x1b[7m Calibrate/Test Completed, Failed. \x1b[0m\r\n");
                return;
            }
        }
        qei1.max = qei1.c;
        emotor_power_off(); // turn off the power first
        mode.free = FALSE; // setup flags so the tracking can work.
        mode.v24 = FALSE;
        knob2.c = (long) ((float) qei1.max * 0.01);
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.666);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.333);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.9);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.1);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        knob2.c = (long) ((float) qei1.max * 0.5);
        motordata[knob_to_pot].pot.error = knob2.c - qei1.c; // find the raw encoder/encoder diff
        track_motor();
        for (z = 0; z < MAX_MOTOR; z++) { // set defaults to pass
            motordata[z].pot.cal_failed = FALSE;
        }
    }

    for (z = 0; z < MAX_MOTOR; z++) { // Lets look at the results of the calibration.
        if (!motordata[z].pot.cal_failed) {
            motordata[z].pot.cal_low = TRUE;
            motordata[z].pot.cal_high = TRUE;
            motordata[z].pot.scaled_set = 500; // mid range
        } else {
            if (motordata[z].active) {
                button.B2 = FALSE;
                p = 'X' + (char) z;
                sprintf(bootstr2, "Motor %c failed cal  ", p); // info display data
                LCD_VC_puts(dsi, DS0, YES);
                sprintf(bootstr2, "Dead   %i,%i      ", motordata[z].pot.pos_change, motordata[z].pot.limit_change);
                LCD_VC_puts(VC0, DS1, YES);
                sprintf(bootstr2, "Span   %i,%i      ", motordata[z].pot.span, motordata[z].pot.limit_span);
                LCD_VC_puts(VC0, DS2, YES);
                sprintf(bootstr2, "Offset %i,%i      ", motordata[z].pot.offset, motordata[z].pot.limit_offset);
                LCD_VC_puts(VC0, DS3, YES);
                blink_led(TEST_LED, TRUE);
                do {
                    buzzer_ticks(2);
                    ClrWdt();
                } while (button.B2 == FALSE);
                blink_led(TEST_LED, FALSE);
                Clear_All_Buttons();
            }
        }
    }
    emotor_power_off(); // turn off the power first
    wdttime(RELAYRUN); // wait for .5 seconds.
    LED_1 = LOW;
    mode.free = FALSE;
    mode.v24 = FALSE;
    Clear_All_Buttons();
    putrs2USART("\x1b[7m Calibrate/Test Completed, PASSED. \x1b[0m\r\n");
}

void display_cal(void) {
    ADC_read();
    if (RS232_DEBUG) {
        sprintf(bootstr2, "Current: X%3li Y%3li Z%3li Raw: ADC X%3i Y%3i Z%3i\r\n", R.current_x, R.current_y, R.current_z, a10_x, a10_y, a10_z);
        puts2USART(bootstr2);
        sprintf(bootstr2, "Position ADC:  X%3li Y%3li Z%3li\r\n", R.pos_x, R.pos_y, R.pos_z);
        puts2USART(bootstr2);
        sprintf(bootstr2, "Pot: Xa%3i Xs%3i Xc%3i Ya%3i Ys%3i Yc%3i Za%3i Zs%3i Zc%3i\r\n\n",
                motordata[0].pot.pos_actual, motordata[0].pot.pos_set, motordata[0].pot.pos_change,
                motordata[1].pot.pos_actual, motordata[1].pot.pos_set, motordata[1].pot.pos_change,
                motordata[2].pot.pos_actual, motordata[2].pot.pos_set, motordata[2].pot.pos_change);
        puts2USART(bootstr2);
    }
}

void init_lcd(void) {
    lcd18 = 200;
    wdtdelay(10000); // delay for power related LCD setup glitch
    if (BusyXLCD()) {
        OpenXLCD(FOUR_BIT & LINES_5X7);
        while (BusyXLCD());
        wdtdelay(10000); // delay for power related LCD setup glitch
        OpenXLCD(FOUR_BIT & LINES_5X7);
        while (BusyXLCD());
        WriteCmdXLCD(0xc); // blink, cursor off
        while (BusyXLCD());
        WriteCmdXLCD(0x1); // clear screen
        wdtdelay(10000);
        LCD_OK = TRUE;
        lcd18 = 24;
    }
}

void main(void) // Lets Party
{
    static unsigned char eep_char = NULL0;
    static unsigned char z = 0;
    static uint8_t menu_pos;

    mode.v24 = FALSE;

#ifdef	__18F8722
    config_pic(PIC_8722); // configure all controller hardware to the correct settings and ports
#endif

    sprintf(bootstr2, "********************"); // blank display data
    LCD_VC_puts(VC0, DS0, YES);
    LCD_VC_puts(VC0, DS1, YES);
    LCD_VC_puts(VC0, DS2, YES);
    LCD_VC_puts(VC0, DS3, YES);

#ifdef	__18F8722
    start_pic(PIC_8722); // configure external hardware to the correct startup conditions
#endif
    ALARMOUT = LOW;
    init_lcd();
    LEDS = R_ALL_ON;

#ifdef	__18F8722
    if (STKPTRbits.STKFUL) {
        STKPTRbits.STKFUL = 0;
        putrs2USART("\r\n");
        term_time();
        putrs2USART("\x1b[7m Restart from Stack Full. \x1b[0m\r\n");
    }
    if (STKPTRbits.STKUNF) {
        STKPTRbits.STKUNF = 0;
        putrs2USART("\r\n");
        term_time();
        putrs2USART("\x1b[7m Restart from Stack Underflow. \x1b[0m\r\n");
    }
#endif

    if (WDT_TO) {
        putrs2USART("\r\n");
        term_time();
        putrs2USART("\x1b[7m Restart from Watchdog Timer. \x1b[0m\r\n");
    }

    if (EEP_ER) {
        putrs2USART("\r\n");
        term_time();
        putrs2USART("\x1b[7m Possible EEPROM write error. \x1b[0m\r\n");
    }

    strncpypgm2ram(bootstr2, START1, LCD_W);
    LCD_VC_puts(VC0, DS0, YES);

    putrs2USART(" FW ");
    strncpypgm2ram(bootstr2, build_time, LCD_W);
    LCD_VC_puts(VC0, DS1, YES);
    puts2USART(bootstr2);
    putrs2USART(" ");

    strncpypgm2ram(bootstr2, build_date, LCD_W);
    puts2USART(bootstr2);
    LCD_VC_puts(VC0, DS2, YES);

    strncpypgm2ram(bootstr2, MANDM_VERSION, LCD_W);
    puts2USART(bootstr2);
    putrs2USART("\r\n");
    LCD_VC_puts(VC0, DS3, YES);

    // leds from outputs to ground via resistor.


    term_time();
    putrs2USART(" Configure operational data \r\n");

    if (DIPSW2 == HIGH) { // enable RS232 extra debug
        RS232_DEBUG = TRUE;
    }

    if (DIPSW1 == HIGH) { // clear data
        term_time();
        putrs2USART(" Init Controller Data \r\n");
        write_data_eeprom(0, 1, 0, 0); // data, number of data slots, postion, offset from eeprom address 0

        term_time();
        putrs2USART(" Init ADC Cal EEPROM Data \r\n");
        for (z = 0; z < ADC_SLOTS; z++) {
            write_data_eeprom(ADC_NULL, ADC_SLOTS, z, 8); // data, number of data slots, postion, offset from eeprom address 0
        }
    }

    term_time();
    putrs2USART(" Read Controller eeprom data \r\n");
    if (read_data_eeprom(0, 0) == CHECKMARK) { // load Controller types from EEPROM
        eep_char = read_data_eeprom(2, 0);
    } else {
        term_time();
        putrs2USART(" Invalid Controller eeprom data \r\n"); // init eeprom data
        write_data_eeprom(0, 1, 0, 0); // data, number of data slots, postion, offset from eeprom address 0
        term_time();
        putrs2USART(" Controller eeprom data saved\r\n"); // init eeprom data
    }

    term_time();
    putrs2USART(" Read ADC eeprom data \r\n");
    if (read_data_eeprom(0, 8) == CHECKMARK) { // load ADC cal data from EEPROM
        for (z = 0; z < ADC_SLOTS; z++) {
            adc_cal[z] = read_data_eeprom(10, z);
        }
    } else {
        term_time();
        putrs2USART(" Invalid ADC eeprom data \r\n"); // init eeprom data
        for (z = 0; z < ADC_SLOTS; z++) {
            write_data_eeprom(adc_cal[z], ADC_SLOTS, z, 8);
        }
        term_time();
        putrs2USART(" ADC eeprom data saved\r\n"); // init eeprom data
    }

    if (DIPSW3 == HIGH) { // failsafe mode
        fail_safe();
        while (TRUE); // Don't  continue
    }

    zero_amploc(); // zero input current sensor
    term_time();
    putrs2USART(" Read ADC data inputs \r\n");
    wdttime(BATRUNF);
    ADC_read();

    if (DIPSW1 == HIGH) { // set default hist and SD data
        term_time();
        putrs2USART(" Init History Data \r\n");
    }

    voltfps(R.systemvoltage, f1);
    voltfps(R.motorvoltage, f2);
    sprintf(bootstr2, "Sys %sV,Mot %sV         ", f1, f2); // display Power info
    LCD_VC_puts(VC0, DS0, YES);

    sprintf(bootstr2, "DIPSW %i%i%i%i%i%i%i%i           ", DIPSW1, DIPSW2,
            DIPSW3, DIPSW4, DIPSW5, DIPSW6, DIPSW7, DIPSW8);
    LCD_VC_puts(VC0, DS1, YES);

    start_delay();

    wdttime(BATRUNF); // read battery and charging system voltages
    ADC_read();
    srand((unsigned int) R.systemvoltage); // set random seed

    /*      Work thread start */
    start_workerthread();
    LEDS = R_ALL_OFF;

    check_cable((uint8_t*) mode.operate);
    init_motordata(mode.operate);

    SYSTEM_STABLE = TRUE;
    voltfps(R.systemvoltage, f1);
    voltfps(R.motorvoltage, f2);
    sprintf(bootstr2, "S%sV,M%sV,Q%5li %5li         ", f1, f2, knob1.c, knob2.c);
    LCD_VC_puts(VC0, DS0, YES);
    start_delay();
    voice1_ticks(40);
    wdttime(BATRUNF);
    mode.move = TRUE;
    Set_Cursor();
    checktime_eep(1, TRUE);

    /* Loop forever */
    while (TRUE) {
        ADC_read();
        if (emotor_is_all_off() && WORKERFLAG) zero_amploc();
        hid_menu();
        ClrWdt(); // reset the WDT timer
        if (mode.cal) {
            run_cal();
            check_cable(&menu_pos);
            update_lcd_menu(menu_pos);
        }
        ClrWdt(); // reset the WDT timer
        update_hist();
        track_motor();
        if (mode.idle) {
            help_pos = 0;
        }
    }
}

